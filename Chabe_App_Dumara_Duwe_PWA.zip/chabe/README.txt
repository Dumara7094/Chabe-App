# Chabe — Production-ready local server package

Admin:
- Name: Dumara
- Username: Dumara7094@@
- Password: chabbe@@1234
- Role: Super Admin

Included:
- Secure server-side login with SHA-256 password hash
- JSON database stored in data/db.json
- Youth registration API and database
- Audit log
- Role field for Super Admin/Data Entry/Report User/Viewer expansion
- OTP endpoint (development OTP shown in console/UI; connect an SMS gateway for real SMS)
- CSV report compatible with Excel
- Print-to-PDF report
- Upload folder prepared at data/uploads

Run:
1. Install Node.js 18+.
2. Open this folder in terminal.
3. Run: node server.js
4. Open: http://localhost:8080

For real office deployment, put HTTPS/reverse proxy in front, replace JSON DB with MySQL/PostgreSQL, connect an SMS provider, implement authenticated file uploads, backups, and server-side RBAC.
