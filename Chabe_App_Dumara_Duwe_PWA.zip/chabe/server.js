const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const ROOT=__dirname, DATA=path.join(ROOT,'data'), UP=path.join(DATA,'uploads'); fs.mkdirSync(UP,{recursive:true});
const db=path.join(DATA,'db.json'); if(!fs.existsSync(db)) fs.writeFileSync(db,JSON.stringify({users:[],youth:[],audit:[]},null,2));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
let D=JSON.parse(fs.readFileSync(db));
if(!D.users.length){D.users=[{id:'u1',name:'Dumara',username:'Dumara7094@@',passwordHash:hash('chabbe@@1234'),role:'Super Admin'}];fs.writeFileSync(db,JSON.stringify(D,null,2));}
const save=()=>fs.writeFileSync(db,JSON.stringify(D,null,2));
const send=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization'});res.end(JSON.stringify(obj));};
const body=req=>new Promise((resolve,reject)=>{let b='';req.on('data',c=>b+=c);req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(e)}})});
const server=http.createServer(async(req,res)=>{if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization'});return res.end()}
 if(req.url==='/api/health')return send(res,200,{ok:true,mode:'local-secure-server'});
 if(req.url==='/api/login'&&req.method==='POST'){const b=await body(req);const u=D.users.find(x=>x.username===b.username&&x.passwordHash===hash(b.password));if(!u)return send(res,401,{error:'የመግቢያ መረጃ ትክክል አይደለም'});const token=crypto.randomBytes(24).toString('hex');D.audit.push({at:new Date().toISOString(),user:u.username,action:'LOGIN'});save();return send(res,200,{token,user:{name:u.name,username:u.username,role:u.role}})}
 if(req.url==='/api/otp'&&req.method==='POST'){const b=await body(req);const otp=String(Math.floor(100000+Math.random()*900000));D.otp={phone:b.phone,otp,expires:Date.now()+300000};save();console.log('OTP for',b.phone,otp);return send(res,200,{ok:true,message:'OTP ተፈጥሯል። በProduction ላይ SMS gateway ይገናኛል።',developmentOtp:otp})}
 if(req.url==='/api/records'&&req.method==='GET')return send(res,200,{records:D.youth});
 if(req.url==='/api/records'&&req.method==='POST'){const b=await body(req);const rec={...b,id:'Y'+Date.now(),createdAt:new Date().toISOString()};D.youth.push(rec);D.audit.push({at:rec.createdAt,user:'public',action:'CREATE',recordId:rec.id});save();return send(res,201,{ok:true,id:rec.id})}
 if(req.url==='/api/users'&&req.method==='GET')return send(res,200,{users:D.users.map(({passwordHash,...u})=>u)});
 if(req.url.startsWith('/')){let f=req.url==='/'?'index.html':req.url.slice(1);f=path.normalize(f);if(f.includes('..'))return send(res,403,{error:'Forbidden'});let p=path.join(ROOT,f);if(fs.existsSync(p)&&fs.statSync(p).isFile()){res.writeHead(200,{'Content-Type':p.endsWith('.html')?'text/html; charset=utf-8':'text/plain'});return fs.createReadStream(p).pipe(res)}}send(res,404,{error:'Not found'});
});server.listen(process.env.PORT||8080,()=>console.log('Chabe server running on http://localhost:'+ (process.env.PORT||8080)));
